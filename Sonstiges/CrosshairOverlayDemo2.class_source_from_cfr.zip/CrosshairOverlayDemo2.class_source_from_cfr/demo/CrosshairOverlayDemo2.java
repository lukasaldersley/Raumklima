/*
 * Decompiled with CFR 0_122.
 * 
 * Could not load the following classes:
 *  demo.CrosshairOverlayDemo2$1
 *  demo.CrosshairOverlayDemo2$MyDemoPanel
 */
package demo;

import demo.CrosshairOverlayDemo2;
import java.awt.Container;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class CrosshairOverlayDemo2
extends JFrame {
    public CrosshairOverlayDemo2(String string) {
        super(string);
        this.setContentPane(CrosshairOverlayDemo2.createDemoPanel());
    }

    public static JPanel createDemoPanel() {
        return new MyDemoPanel();
    }

    public static void main(String[] arrstring) {
        SwingUtilities.invokeLater((Runnable)new /* Unavailable Anonymous Inner Class!! */);
    }
}
